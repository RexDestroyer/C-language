#include<stdlib.h>
#include<locale.h>
#include<stdio.h>

main () {
	
	setlocale(LC_ALL,"Portuguese");
	
	int cont, n, resultado;
	cont = 1;
	
	printf("Digite um n�mero: ");
	scanf("%d", &n);
	
	
	while (11 > cont) {	
	resultado = n * cont;
	cont = cont + 1;
	printf("%d \n", resultado);	
	}
	

system("PAUSE");

}
	
